
-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `f_name` text NOT NULL,
  `l_name` text NOT NULL,
  `user_name` text NOT NULL,
  `describe_user` varchar(255) NOT NULL,
  `Relationship` text NOT NULL,
  `user_pass` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_country` text NOT NULL,
  `user_gender` text NOT NULL,
  `user_birthday` text NOT NULL,
  `user_image` varchar(255) NOT NULL,
  `user_cover` varchar(255) NOT NULL,
  `user_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` text NOT NULL,
  `posts` text NOT NULL,
  `recovery_account` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `f_name`, `l_name`, `user_name`, `describe_user`, `Relationship`, `user_pass`, `user_email`, `user_country`, `user_gender`, `user_birthday`, `user_image`, `user_cover`, `user_reg_date`, `status`, `posts`, `recovery_account`) VALUES
(1, 'obo', 'bo', 'obo_bo_890730', 'Hello WeShare. This is my default status!', '...', '123456789', 'che@gmail.com', 'Cameroun', 'Male', '2020-05-13', 'head_sun_flower.jpg', 'default_cover.jpg', '2020-05-15 16:03:51', 'verified', 'no', 'Demo'),
(4, 'Fopa', 'Demo', 'obo_demo_255980', 'Hello WeShare. This is my default status!', 'Single', 'demoFkd#2000', 'fopaduclair2000@gmail.com', 'India', 'Male', '2020-05-02', 'demo.jpg.34', 'feature-5.jpg.57', '2020-05-16 04:30:41', 'verified', 'yes', 'Ndem'),
(6, 'Cobra', 'Gildas', 'cobra_gildas_85771', 'Hello WeShare. This is my default status!', '...', 'algorithme', 'fopaduclair2000@gmail.com', 'Cameroun', 'Male', '2021-11-02', 'head_read.jpg', 'default_cover.jpg', '2020-05-17 16:37:07', 'verified', 'no', 'Demo'),
(7, 'Isco', 'Ismael', 'isco_ismael_549969', 'Hello WeShare. This is my default status!', '...', 'demoFkd#2000', 'demo@gmail.com', 'Rwanda', 'Male', '2020-05-03', 'head_sun_flower.jpg', 'default_cover.jpg', '2020-05-19 08:20:29', 'verified', 'yes', 'Demo'),
(8, '@OBO', 'claude', '@obo_claude_508867', 'Hello WeShare. This is my default status!', '...', '123456789q', 'chedjouclaudebblack@gmail.com', 'CM', 'Male', '0031-04-02', 'FB_IMG_15822888489907845.jpg.75', 'default_cover.jpg', '2020-05-21 10:43:32', 'verified', 'yes', 'Demo'),
(9, '@Demo', 'Fkd', '@demo_fkd_804158', 'Hello WeShare. This is my default status!', '...', 'algorithmedemo', 'fopaduclair2000@gmail.com', 'IN', 'Male', '2002-04-01', 'head_read.jpg', 'default_cover.jpg', '2020-05-21 10:54:02', 'verified', 'no', 'Demo'),
(10, '@Demo', 'Fkd', '@demo_fkd_234600', 'Hello WeShare. This is my default status!', '...', 'programmation', 'fopaduclair2000@gmail.com', 'IN', 'Male', '2002-04-01', 'head_read.jpg', 'default_cover.jpg', '2020-05-21 10:55:49', 'verified', 'no', 'Demo'),
(12, 'Ndem', 'Baba', 'ndem_baba_337384', 'Hello WeShare. This is my default status!', '...', 'demo20002002', 'ndemo@gmail.com', 'BZ', 'Male', '6678-05-31', 'head_read.jpg', 'default_cover.jpg', '2020-05-22 09:01:05', 'verified', 'yes', 'Demo'),
(14, 'fkduclair', 'fkd', 'fkduclair_fkd_427044', 'Hello WeShare. This is my default status!', '...', 'algorithme', 'itel@gmail.com', 'BD', 'Male', '4002-03-12', 'head_read.jpg', 'default_cover.jpg', '2020-05-26 17:30:21', 'verified', 'yes', 'Demo'),
(15, 'FopaKuete', 'Duclair', 'fopakuete_duclair_295081', 'Hello WeShare. This is my default status!', '...', 'demo20002002', 'algorithme@gmail.com', 'BG', 'Male', '2000-03-12', 'demo.jpg.44', 'blog-3.jpg.96', '2020-05-27 07:14:30', 'verified', 'yes', 'Demo'),
(16, 'Local', 'fopa', 'local_fopa_147968', 'Hello WeShare. This is my default status!', '...', 'itledemo2000', 'fopa@gmail.com', 'CL', 'Male', '4567-03-12', 'head_sun_flower.jpg', 'default_cover.jpg', '2020-05-28 16:29:44', 'verified', 'yes', 'Demo'),
(17, 'Maxime', 'Roland', 'maxime_roland_827846', 'Hello WeShare. This is my default status!', '...', 'password2000', 'max@gmail.com', 'CN', 'Male', '2002-12-12', 'head_turquoise.jpg', 'default_cover.jpg', '2020-05-28 16:55:13', 'verified', 'yes', 'Demo'),
(18, 'Tagne', 'Ismael', 'tagne_ismael_238329', 'Hello WeShare. This is my default status!', '...', 'algorithme20002002', 'tagne@gmail.com', 'EC', 'Male', '2000-03-12', 'head_read.jpg', 'default_cover.jpg', '2020-05-28 17:32:52', 'verified', 'yes', 'Demo'),
(19, 'David', 'Cliff', 'david_cliff_951827', 'Hello WeShare. This is my default status!', '...', '1234567890', 'dav@gmai.com', 'BE', 'Male', '1994-05-16', 'head_sun_flower.jpg', 'default_cover.jpg', '2020-05-29 11:08:23', 'verified', 'no', 'Demo'),
(20, 'David1', 'claude', 'david1_claude_171253', 'Hello WeShare. This is my default status!', '...', 'qwertyuiop', 'fr@gmail.com', 'BE', 'Male', '1998-05-23', 'head_read.jpg', 'default_cover.jpg', '2020-05-29 11:10:56', 'verified', 'yes', 'Demo');
