
-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `com_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`com_id`, `post_id`, `user_id`, `comment`, `comment_author`, `date`) VALUES
(2, 12, 4, '<p>c<strong><em>ool mon ptit how are u? Bien au mieux</em></strong></p>', 'obo_demo_255980', '2020-05-18 10:44:41'),
(3, 12, 4, '<p><span style=\"color:#f39c12\">Hope u are doing well</span></p>', 'obo_demo_255980', '2020-05-18 10:45:43'),
(4, 12, 4, '@Demo vous salut', 'obo_demo_255980', '2020-05-18 10:56:29'),
(5, 5, 4, 'nice\r\n', 'obo_demo_255980', '2020-05-18 15:18:31'),
(6, 12, 4, 'cool bro', 'obo_demo_255980', '2020-05-18 17:54:50'),
(7, 14, 7, 'heill', 'isco_ismael_549969', '2020-05-19 08:26:13'),
(8, 15, 4, 'great', 'obo_demo_255980', '2020-05-20 18:04:58'),
(9, 16, 4, 'cool how are you ?', 'obo_demo_255980', '2020-05-21 12:51:20'),
(10, 16, 4, 'demo', 'obo_demo_255980', '2020-05-22 07:46:40'),
(11, 16, 4, 'algo', 'obo_demo_255980', '2020-05-22 07:48:05'),
(12, 4, 4, 'cool', 'obo_demo_255980', '2020-05-22 08:19:45'),
(13, 1, 4, 'thanks bro!!', 'obo_demo_255980', '2020-05-23 05:10:24'),
(14, 19, 4, 'greet', 'obo_demo_255980', '2020-05-23 08:22:35'),
(15, 19, 4, 'cool', 'obo_demo_255980', '2020-05-23 08:34:42'),
(16, 20, 4, 'Le Demo', 'obo_demo_255980', '2020-05-23 08:59:40'),
(17, 18, 4, 'Demo', 'obo_demo_255980', '2020-05-23 09:49:19'),
(18, 20, 4, 'sles', 'obo_demo_255980', '2020-05-23 10:47:14'),
(19, 20, 4, 'demo\r\n', 'obo_demo_255980', '2020-05-23 10:59:47'),
(20, 22, 4, 'Nous allons bien et toi ?', 'obo_demo_255980', '2020-05-23 23:26:26'),
(21, 33, 4, 'Hello friend how are you', 'obo_demo_255980', '2020-05-24 16:01:14'),
(22, 19, 4, 'nice my friend', 'obo_demo_255980', '2020-05-25 06:05:07'),
(23, 35, 8, 'ok ok', '@obo_claude_508867', '2020-05-26 11:09:36'),
(24, 34, 4, 'Demo Le matheux comment vas-tu ?', 'obo_demo_255980', '2020-05-26 15:09:45'),
(25, 34, 4, 'cool', 'obo_demo_255980', '2020-05-26 15:11:22'),
(26, 49, 14, 'great one here', 'fkduclair_fkd_427044', '2020-05-26 17:32:16'),
(27, 54, 15, 'Nice one there', 'fopakuete_duclair_295081', '2020-05-27 07:18:57'),
(28, 52, 4, 'DEMO LE MATHEUX', 'obo_demo_255980', '2020-05-27 11:28:30');
