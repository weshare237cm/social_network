
-- --------------------------------------------------------

--
-- Structure de la table `followers`
--

CREATE TABLE `followers` (
  `id` int(11) NOT NULL,
  `follower_id` int(11) NOT NULL,
  `followed_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Déchargement des données de la table `followers`
--

INSERT INTO `followers` (`id`, `follower_id`, `followed_id`) VALUES
(127, 4, 14),
(128, 4, 1),
(129, 4, 1),
(130, 4, 12),
(131, 4, 12),
(132, 4, 8),
(133, 4, 8),
(134, 4, 8),
(135, 4, 8),
(136, 4, 8),
(137, 14, 10),
(138, 14, 10),
(139, 14, 10),
(140, 14, 1),
(141, 14, 1),
(142, 4, 6),
(143, 16, 8),
(144, 16, 4),
(145, 16, 6),
(146, 16, 7),
(147, 16, 1),
(148, 16, 9),
(149, 16, 12),
(150, 16, 14),
(151, 16, 14),
(152, 16, 10),
(153, 16, 15),
(154, 17, 4),
(155, 17, 4),
(156, 17, 4),
(157, 17, 1),
(158, 17, 6),
(159, 17, 16),
(160, 18, 7),
(161, 18, 4),
(165, 15, 1);
